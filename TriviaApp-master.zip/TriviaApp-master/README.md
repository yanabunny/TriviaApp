# TriviaApp
IOS App on Random Trivia
